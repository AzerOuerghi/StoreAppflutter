
class CategoriesByFilterParams {
  final int categoryId;

  CategoriesByFilterParams({
    this.categoryId
  });
}