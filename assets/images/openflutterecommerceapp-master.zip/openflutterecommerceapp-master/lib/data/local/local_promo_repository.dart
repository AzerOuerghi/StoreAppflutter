import 'package:openflutterecommerce/data/model/promo.dart';
import 'package:openflutterecommerce/data/repositories/abstract/promo_repository.dart';

class LocalPromoRepository implements PromoRepository {
  @override
  Future<List<Promo>> getPromoList() {
    // TODO: implement getPromoList
    return null;
  }
  
}
