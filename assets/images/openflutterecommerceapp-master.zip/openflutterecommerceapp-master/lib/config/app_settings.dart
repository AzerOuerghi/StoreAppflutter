class AppSettings {
  static bool cacheIsEnabled;
  static bool profileEnabled = true;
}
